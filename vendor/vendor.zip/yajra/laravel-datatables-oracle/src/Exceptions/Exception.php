<?php

namespace Yajra\DataTables\Exceptions;

class Exception extends \Exception
{
}
